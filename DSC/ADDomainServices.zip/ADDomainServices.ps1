﻿Configuration AddDns 
{ 
    param ()

    Import-DscResource -ModuleName DnsServerDsc, NetworkingDsc

    $Interface=Get-NetAdapter | Where-Object Name -Like "Ethernet*" | Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    WindowsFeature DNS 
    { 
        Ensure = "Present" 
        Name = "DNS"		
    }

    WindowsFeature DnsTools
    {
        Ensure = "Present"
        Name = "RSAT-DNS-Server"
    }

    DnsServerDiagnostics DnsDiagnostics
    {
        DnsServer = "127.0.0.1"
        Answers = $true
        EnableLoggingForLocalLookupEvent = $true
        EnableLoggingForPluginDllEvent = $true
        EnableLoggingForRecursiveLookupEvent = $true
        EnableLoggingForRemoteServerEvent = $true
        EnableLoggingForServerStartStopEvent = $true
        EnableLoggingForTombstoneEvent = $true
        EnableLoggingForZoneDataWriteEvent = $true
        EnableLoggingForZoneLoadingEvent = $true
        FullPackets = $true
        Notifications = $true
        Queries = $true
        QuestionTransactions = $true
        ReceivePackets = $true
        SaveLogsToPersistentStorage = $true
        SendPackets = $true                          
        TcpPackets = $true
        UdpPackets = $true
        UnmatchedResponse = $true
        Update = $true
        UseSystemEventLog = $true
        DependsOn = "[WindowsFeature]DNS"
    }

    DNSServerAddress DnsServerAddress 
    { 
        Address        = '127.0.0.1' 
        InterfaceAlias = $InterfaceAlias
        AddressFamily  = 'IPv4'
        DependsOn = "[WindowsFeature]DNS"
    }
}

Configuration NewDomain 
{ 
    param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 

    Import-DscResource -ModuleName ActiveDirectoryDsc, StorageDsc

    $DomainUserName = [string]::Join("\", @($DomainName, $($Admincreds.UserName)))
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential `
        ($DomainUserName, $Admincreds.Password)

    WindowsFeature ADTools
    {
        Ensure = "Present"
        Name = "RSAT-AD-Tools"
    }

    WaitForDisk ADDataDisk
    {
        DiskId = "2"
        DiskIdType = "Number"
        RetryIntervalSec =$RetryIntervalSec
        RetryCount = $RetryCount
    }

    Disk ADDataDisk
    {
        DiskId = "2"
        DiskIdType = "Number"
        DriveLetter = "F"
        FSFormat = "NTFS"
        PartitionStyle = "GPT"
        Dependson = "[WaitForDisk]ADDataDisk"
    }

    WindowsFeature ADDSInstall 
    { 
        Ensure = "Present" 
        Name = "AD-Domain-Services"
        DependsOn="[Disk]ADDataDisk"
    } 

    # Creates a new Domain in a new AD Forest -or- a child domain in an existing Forest
    ADDomain NewDomain 
    {
        Credential = $DomainCreds
        DomainName = $DomainName
        SafemodeAdministratorPassword = $DomainCreds
        DomainNetBiosName = $DomainName.split('.')[0]
        DatabasePath = "F:\NTDS"
        LogPath = "F:\NTDS"
        SysvolPath = "F:\SYSVOL"
        DependsOn = "[WindowsFeature]ADDSInstall"
    } 
}

Configuration PromoteDC 
{ 
    param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 

    Import-DscResource -ModuleName ActiveDirectoryDsc, StorageDsc

    $DomainUserName = [string]::Join("\", @($DomainName, $($Admincreds.UserName)))
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential `
        ($DomainUserName, $Admincreds.Password)

    WindowsFeature ADTools
    {
        Ensure = "Present"
        Name = "RSAT-AD-Tools"
    }

    WaitForDisk ADDataDisk
    {
        DiskId = "2"
        DiskIdType = "Number"
        RetryIntervalSec =$RetryIntervalSec
        RetryCount = $RetryCount
    }

    Disk ADDataDisk
    {
        DiskId = "2"
        DiskIdType = "Number"
        DriveLetter = "F"
        FSFormat = "NTFS"
        PartitionStyle = "GPT"
        Dependson = "[WaitForDisk]ADDataDisk"
    }

    WindowsFeature ADDSInstall 
    { 
        Ensure = "Present" 
        Name = "AD-Domain-Services"
        DependsOn="[Disk]ADDataDisk"
    } 

    ADDomainController PromoteDC
    {
        Credential = $DomainCreds
        DomainName = $DomainName
        SafemodeAdministratorPassword = $DomainCreds
        DatabasePath = "F:\NTDS"
        LogPath = "F:\NTDS"
        SysvolPath = "F:\SYSVOL"
        InstallDns = $false
        DependsOn = "[WindowsFeature]ADDSInstall"
    }
} 

Configuration ApplyNewDomain
{
    param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    ) 

    Import-DscResource -ModuleName PSDesiredStateConfiguration

    Node localhost
    {
        AddDns ApplyNewDomainResource {}

        NewDomain ApplyNewDomainResource
        {
            DomainName = $DomainName
            AdminCreds = $Admincreds
        }

        LocalConfigurationManager 
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
    }
}

Configuration ApplyPromoteDC
{
    param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds
    ) 

    Import-DscResource -ModuleName PSDesiredStateConfiguration
	
    Node localhost
    {
        AddDns ApplyPromoteDCResource {}

        PromoteDC ApplyPromoteDCResource
        {
            DomainName = $DomainName
            AdminCreds = $Admincreds
        }

        LocalConfigurationManager 
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
    }
}
